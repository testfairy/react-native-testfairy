package com.testfairy;

import java.io.Serializable;

public class FeedbackOptions implements Serializable {

	public boolean isEmailFieldVisible() {
		// stub
	}

	/**
	 * Returns the mandatory email requirement as resolved by {@link Builder#build()}, which is not
	 * necessarily the value passed to {@link Builder#setEmailMandatory(boolean)}. The requirement is
	 * lifted when the form has no email input, so a hidden email field or a custom field list
	 * without ":userId" makes this return false.
	 *
	 * @return Boolean
	 */
	public boolean isEmailMandatory() {
		// stub
	}

	public boolean isTakeScreenshotButtonVisible() {
		// stub
	}

	public boolean isTakeRecordingButtonVisible() {
		// stub
	}

	public Callback getFeedbackCallback() {
		// stub
	}

	public String getBrowserUrl() {
		// stub
	}

	public String getDefaultFeedbackText() {
		// stub
	}

	public FeedbackInterceptor getFeedbackInterceptor() {
		// stub
	}

	public List<FeedbackFormField> getFeedbackFormFields() {
		// stub
	}

	public static class Builder {

		/**
		 * Determines whether the "email field" in the Feedback form will be visible or not.
		 * default is true.
		 * Hiding the email field also lifts the mandatory email requirement, unless
		 * setEmailMandatory(true) is called afterwards (which makes the field visible again).
		 * @param visible Boolean
		 * @return Builder
		 */
		public Builder setEmailFieldVisible(boolean visible) {
			// stub
		}

		/**
		 * Determines whether the user has to add his email address to the feedback.
		 * if true, it automatically sets setEmailFieldVisible = true.
		 * default is true, for consistency with the iOS SDK.
		 * @param mandatory Boolean
		 * @return Builder
		 */
		public Builder setEmailMandatory(boolean mandatory) {
			// stub
		}

		/**
		 * By setting the callback, You will be notified for "onFeedbackSent", "onFeedbackCancelled" and "onFeedbackFailed"
		 *
		 * @param callback FeedbackOptions.Callback
		 * @return Builder
		 */
		public Builder setCallback(Callback callback) {
			// stub
		}


		/**
		 * By setting the url, You will override the default TestFairy feedback form,
		 * The specified url will be opened in the browser, when the user will want to provide a feedback.
		 * The following parameters will be added (if exsist) to the url
		 * sessionUrl, correlationId, email, timestamp, platform, packageName, versionName and versionCode.
		 *
		 * Note setCallback(), setEmailMandatory(), setEmailFieldVisible() are invalid in this case.
		 * @param url String
		 * @return Builder
		 */
		public Builder setBrowserUrl(String url) {
			// stub
		}

		/**
		 * By setting a default text, you will override the initial content of the text area
		 * inside the feedback form. This way, you can standardize the way you receive feedbacks
		 * by specifying guidelines to your users.
		 *
		 * @param defaultText
		 * @return
		 */
		public Builder setDefaultText(String defaultText) {
			// stub
		}

		/**
		 * By setting this flag, you can show/hide "Take a screenshot" button.
		 * Set to true if never called.
		 *
		 * @param enabled
		 * @return
		 */
		public Builder setTakeScreenshotButtonVisible(boolean enabled) {
			// stub
		}

		/**
		 * By setting this flag, you can show/hide "Take a screen recording" button.
		 * Set to true if never called.
		 *
		 * @param enabled
		 * @return
		 */
		public Builder setRecordVideoButtonVisible(boolean enabled) {
			// stub
		}

		/**
		 * By setting this interface, feedback can become available for inspection before
		 * they are submitted. The contents of the feedback can be modified.
		 *
		 * i.e A business may want to append a string consist of important meta data to the end of user message.
		 *
		 * @param feedbackInterceptor
		 * @return
		 */
		public Builder setFeedbackInterceptor(FeedbackInterceptor feedbackInterceptor) {
			// stub
		}

		/**
		 * By setting this list, feedback forms can be customized with extra input fields.
		 * Calling with a null list will enable the default fields, namely email and feedback message.
		 * A custom list without a ":userId" field has no email input, so the mandatory email
		 * requirement is lifted for it.
		 *
		 * @param feedbackFormFields
		 * @return
		 */
		public Builder setFeedbackFormFields(List<FeedbackFormField> feedbackFormFields) {
			// stub
		}

		/**
		 * Create FeedbackOptions.
		 * The mandatory email requirement is resolved here and only applies when the form actually
		 * has an email input, so {@link FeedbackOptions#isEmailMandatory()} can return false even
		 * after setEmailMandatory(true), for example when the email field is hidden or a custom
		 * field list has no ":userId" field.
		 *
		 * @return FeedbackOptions
		 */
		public FeedbackOptions build() {
			// stub
		}
	}

	public interface Callback {
		int REASON_NETWORK_ERROR = 1;

		void onFeedbackSent(FeedbackContent feedbackContent);
		void onFeedbackCancelled();
		void onFeedbackFailed(int reason, FeedbackContent feedbackContent);
	}

	public interface FeedbackInterceptor {
		FeedbackContent intercept(FeedbackContent feedbackContent);
	}
}
