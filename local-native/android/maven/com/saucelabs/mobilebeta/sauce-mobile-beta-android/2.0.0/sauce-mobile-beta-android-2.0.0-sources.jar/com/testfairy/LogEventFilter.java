package com.testfairy;

public interface LogEventFilter {
	/**
	 * Accept a log event entry. By returning true, TestFairy will send this log to server.
	 * Otherwise, log event will be discarded.
	 *
	 * @param level String
	 * @param tag   String
	 * @param text  String
	 * @return boolean
	 */
	boolean accept(String level, String tag, String text);
}