package com.testfairy;

import com.testfairy.FeedbackContent;

public interface FeedbackVerifier {
	/**
	 * A callback from the feedback form to verify the contents that the user
	 * has inputed. Use this to verify the email address, specific address of the
	 * content, or any other information available in FeedbackContent.
	 *
	 * @param content {@link FeedbackContent}
	 * @return true if verification passed
	 */
	boolean verifyFeedback(FeedbackContent content);

	/**
	 * A callback to get the error message after a failure from verifyFeedback()
	 * method. This will only be called after verifyFeedback returned false.
	 *
	 * @return Error message to be displayed on screen
	 */
	String getVerificationFailedMessage();
}