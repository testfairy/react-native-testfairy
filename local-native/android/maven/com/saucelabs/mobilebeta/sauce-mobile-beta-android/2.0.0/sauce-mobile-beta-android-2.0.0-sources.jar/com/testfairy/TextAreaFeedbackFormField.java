package com.testfairy;

import android.content.Context;
import android.content.res.Resources;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

/**
 * A simple form element for editable text area.
 */
public class TextAreaFeedbackFormField implements FeedbackFormField, TextWatcher {

	private static final int MARGIN = 25;

	private final String attribute;
	private final String placeholder;
	private final String defaultValue;

	private String fieldValue;

	public TextAreaFeedbackFormField(String attribute, String placeholder, String defaultValue) {
		this.attribute = attribute != null ? attribute : "";
		this.placeholder = placeholder != null ? placeholder : "";
		this.defaultValue = defaultValue != null ? defaultValue : "";
		this.fieldValue = this.defaultValue;
	}

	@Override
	public View onCreateView(Context context, View parent) {
		EditText feedbackText = new EditText(context);
		feedbackText.setContentDescription(placeholder);
		feedbackText.setHint(placeholder);
		feedbackText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
		feedbackText.setMinimumHeight((int) dpToPx(context, 100));
		feedbackText.setMinHeight((int) dpToPx(context, 100));
		feedbackText.setGravity(Gravity.TOP | Gravity.LEFT);
		feedbackText.setText(defaultValue);
		feedbackText.addTextChangedListener(this);

		if (parent instanceof LinearLayout) {
			LinearLayout.LayoutParams feedbackTextLP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			feedbackTextLP.setMargins(MARGIN, MARGIN, MARGIN, MARGIN * 2);
			feedbackText.setLayoutParams(feedbackTextLP);
		}

		return feedbackText;
	}

	@Override
	public String getValue() {
		return fieldValue;
	}

	@Override
	public String getAttribute() {
		return attribute;
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {

	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		fieldValue = s != null ? s.toString() : "";
	}

	@Override
	public void afterTextChanged(Editable s) {

	}

	private static float dpToPx(Context context, float dp) {
		Resources r = context.getResources();
		return TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP,
			dp,
			r.getDisplayMetrics()
		);
	}
}
