package com.testfairy;

import android.content.Context;
import android.view.View;

/**
 * Common interface for all custom feedback form fields
 */
public interface FeedbackFormField {
	/**
	 * Like an adapter, implement this to return a custom view for the form element
	 *
	 * @param context
	 * @param parent
	 * @return
	 */
	View onCreateView(Context context, View parent);

	/**
	 * Return the key name for the attribute represented by this form field
	 *
	 * @return
	 */
	String getAttribute();

	/**
	 * Return the value for the attribute respressented by this form field
	 *
	 * @return
	 */
	String getValue();
}
