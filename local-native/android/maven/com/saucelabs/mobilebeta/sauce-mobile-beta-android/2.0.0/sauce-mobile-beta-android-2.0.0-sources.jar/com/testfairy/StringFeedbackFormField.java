package com.testfairy;

import android.content.Context;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

/**
 * A simple form element for editable string inputs
 */
public class StringFeedbackFormField implements FeedbackFormField, TextWatcher {

	private static final int MARGIN = 25;

	private final String attribute;
	private final String placeholder;
	private final String defaultValue;

	private String fieldValue;

	public StringFeedbackFormField(String attribute, String placeholder, String defaultValue) {
		this.attribute = attribute != null ? attribute : "";
		this.placeholder = placeholder != null ? placeholder : "";
		this.defaultValue = defaultValue != null ? defaultValue : "";
		this.fieldValue = defaultValue;
	}

	@Override
	public View onCreateView(Context context, View parent) {
		EditText editText = new EditText(context);
		editText.setContentDescription(placeholder);
		editText.setHint(placeholder);
		editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
		editText.addTextChangedListener(this);
		editText.setText(defaultValue);

		if (parent instanceof LinearLayout) {
			LinearLayout.LayoutParams emailEditTextLP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			emailEditTextLP.setMargins(MARGIN, MARGIN, MARGIN, MARGIN);
			editText.setLayoutParams(emailEditTextLP);
		}

		return editText;
	}

	@Override
	public String getValue() {
		return fieldValue;
	}

	@Override
	public String getAttribute() {
		return attribute;
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {

	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		fieldValue = s != null ? s.toString() : "";
	}

	@Override
	public void afterTextChanged(Editable s) {
	}
}
