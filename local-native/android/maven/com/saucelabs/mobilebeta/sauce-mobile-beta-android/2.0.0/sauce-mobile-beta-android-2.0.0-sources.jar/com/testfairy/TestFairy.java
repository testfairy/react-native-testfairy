package com.testfairy;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.location.Location;
import android.view.View;

import java.io.File;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

public class TestFairy {

	/**
	 * Initialize a TestFairy session.
	 *
	 * In the crashless Sauce Mobile Beta artifact this method automatically disables TestFairy crash reporting.
	 * Backtrace remains the crash owner.
	 *
	 * @param context  Context
	 * @param appToken Your token as given to you in your TestFairy account
	 */
	public static void begin(Context context, String appToken) {
		//stub
	}

	/**
	 * Initialize a TestFairy session with additional options.
	 *
	 * In the crashless Sauce Mobile Beta artifact enableCrashReporter is forced to false without modifying the caller's map.
	 *
	 * @param context Context
	 * @param appToken Your token as given to you in your TestFairy account
	 * @param options Additional key value pairs, please refer to documentation or contact support
	 */
	public static void begin(Context context, String appToken, Map<String, String> options) {
		//stub
	}

	/**
	 * Initialize a session without installing the TestFairy crash handler.
	 *
	 * Use this when Backtrace is installed in the same app.
	 * Backtrace must be the sole crash owner.
	 *
	 * @param context Context
	 * @param appToken Your token as given to you in your account
	 */
	public static void beginWithoutCrashHandler(Context context, String appToken) {
		//stub
	}

	/**
	 * Initialize a session without installing the TestFairy crash handler.
	 *
	 * This method copies the supplied map and forces enableCrashReporter to false.
	 * The caller's map is not modified.
	 *
	 * @param context Context
	 * @param appToken Your token as given to you in your account
	 * @param options Additional key value pairs
	 */
	public static void beginWithoutCrashHandler(Context context, String appToken, Map<String, String> options) {
		//stub
	}

	/**
	 * Override the server endpoint address for using with on-premise installations
	 * and private cloud configuration. Please contact support for more information
	 * about these products.
	 *
	 * @param serverEndpoint host address
	 */
	public static void setServerEndpoint(String serverEndpoint) {
		//stub
	}

	/**
	 * Returns SDK version (x.x.x) string
	 *
	 * @return SDK version
	 */
	public static String getVersion() {
		//stub
	}

	/**
	 * Hides a specific view from appearing in the video generated.
	 *
	 * @param view View to hide from video
	 */
	public static void hideView(View view) {
		//stub
	}

	/**
	 * Hides a specific view from appearing in the video generated.
	 *
	 * @param viewId Id of the View to hide, i.e R.id.hideMe
	 */
	public static void hideView(Integer viewId) {
		//stub
	}

	/**
	 * Hides a specific html element from appearing in the video generated, detected via a CSS selector.
	 *
	 * @param cssSelector CSS selector to locate the element to hide
	 */
	public static void hideWebViewElements(String cssSelector) {
		//stub
	}

	/**
	 * Send a feedback on behalf of the user. Call when using a in-house feedback activity with a custom
	 * design and feel. Feedback will be associated with the current session.
	 *
	 * @param feedback User feedback to be sent
	 */
	public static void sendUserFeedback(String feedback) {
		//stub
	}

	/**
	 * Send a feedback on behalf of the user. Call when using a in-house feedback activity with a custom
	 * design and feel. Feedback will be associated with the current session.
	 *
	 * @param feedback User feedback to be sent
	 * @param screenshot Screenshot to attach to the feedback
	 */
	public static void sendUserFeedback(String feedback, Bitmap screenshot) {
		//stub
	}

	/**
	 * Send a feedback on behalf of the user. Call when using a in-house feedback activity with a custom
	 * design and feel. Feedback will be sent anonymously.
	 *
	 * @param context Application or Activity context
	 * @param appToken Your app token
	 * @param feedback User feedback to be sent
	 */
	public static void sendUserFeedback(Context context, String appToken, String feedback) {
		//stub
	}

	/**
	 * Send a feedback on behalf of the user. Call when using a in-house feedback activity with a custom
	 * design and feel. Feedback will be sent anonymously.
	 *
	 * @param context Application or Activity context
	 * @param appToken Your app token
	 * @param feedback User feedback to be sent
	 * @param screenshot Screenshot to attach to the feedback
	 */
	public static void sendUserFeedback(Context context, String appToken, String feedback, Bitmap screenshot) {
		//stub
	}

	/**
	 * Proxy onLocationChanged calls, and TestFairy will mark this location/time in the session
	 * being recorded.
	 *
	 * @param location Location
	 */
	public static void updateLocation(Location location) {
		//stub
	}

	/**
	 * Send audio data as Wave/Riff (.wav) file. The encoding that should be used is PCM 16bit
	 * with a single, mono channel.
	 *
	 * @param audioSample AudioSample
	 */
	public static void addAudioRecording(AudioSample audioSample) {
		//stub
	}

	/**
	 * @param name String
	 * @deprecated use {@link #addEvent(String)} instead.
	 */
	@Deprecated
	public static void addCheckpoint(String name) {
		//stub
	}

	/**
	 * Marks an event in session. Use this text to tag a session with an event name. Later you can filter
	 * sessions where your user passed through this checkpoint, for bettering understanding user experience
	 * and behavior.
	 *
	 * @param eventName String
	 */
	public static void addEvent(String eventName) {
		//stub
	}

	/**
	 * Sets a correlation identifier for this session. This value can be looked up via web dashboard. For
	 * example, setting correlation to the value of the user-id after they logged in. Can be called only once per
	 * session (subsequent calls will be ignored.)
	 *
	 * @param correlationId Identifier for this session
	 * @deprecated use {@link #setUserId(String)} instead.
	 */
	@Deprecated
	public static void setCorrelationId(String correlationId) {
		//stub
	}

	/**
	 * Sets a correlation identifier for this session. This value can be looked up via web dashboard. For
	 * example, setting correlation to the value of the user-id after they logged in. Can be called only once per
	 * session (subsequent calls will be ignored.)
	 *
	 * @param correlationId String
	 * @param identifyTrait Map
	 * @deprecated use {@link #setUserId(String)} and {@link #setAttribute(String, String)} instead.
	 */
	@Deprecated
	public static void identify(String correlationId, Map<String, Object> identifyTrait) {
		//stub
	}

	/**
	 * Sets a correlation identifier for this session. This value can be looked up via web dashboard. For
	 * example, setting correlation to the value of the user-id after they logged in. Can be called only once per
	 * session (subsequent calls will be ignored.)
	 *
	 * @param correlationId String
	 * @deprecated use {@link #setUserId(String)} instead.
	 */
	@Deprecated
	public static void identify(String correlationId) {
		//stub
	}

	/**
	 * Use this function to tell TestFairy who is the user,
	 * It will help you to search the specific user in the TestFairy dashboard.
	 * We recommend passing values such as email, phone number, or user id that your app may use.
	 *
	 * @param userId We recommend to use email as userId, But It can be phone number or any other unique id.
	 */
	public static void setUserId(String userId) {
		//stub
	}

	/**
	 * Records an attribute that will be added to the session.
	 *
	 * NOTE: The SDK limits you to storing 64 attribute keys. Adding more than 64 will fail and return false.
	 *
	 * @param key The key of the attribute
	 * @param value The value associated with the attribute max size of 1kb
	 * @return boolean true if successfully set attribute value, otherwise false
	 */
	public static boolean setAttribute(String key, String value) {
		//stub
	}

	/**
	 * Returns the address of the recorded session on TestFairy’s developer portal. Will return null if
	 * recording not yet started.
	 *
	 * @return URL address
	 */
	public static String getSessionUrl() {
		//stub
	}

	/**
	 * Displays the feedback activity. Allow users to provide feedback
	 * about the current session. All feedback will appear in your
	 * build report page, and in the recorded session page.
	 *
	 * Must be called after {@link #begin(Context, String)}.
	 */
	public static void showFeedbackForm() {
		//stub
	}

	/**
	 * Displays the feedback activity. Allow users to provide feedback
	 * about the current session. All feedback will appear in your
	 * build report page, and in the recorded session page. Given
	 * screenshot will be attached to the feedback.
	 *
	 * Must be called after {@link #begin(Context, String)}.
	 *
	 * @param screenshot
	 */
	public static void showFeedbackForm(Bitmap screenshot) {
		//stub
	}

	/**
	 * Displays the feedback activity. Allow users to provide feedback without
	 * prior call to {@link #begin(Context, String)}. All feedback will appear in your
	 * build report page, and in the "Feedbacks" tab.
	 *
	 * This method is different from {@link #showFeedbackForm()} by that it does not
	 * require a call to begin().
	 *
	 * @param context
	 * @param appToken
	 * @param takeScreenshot
	 */
	public static void showFeedbackForm(Context context, String appToken, boolean takeScreenshot) {
		//stub
	}

	/**
	 * Displays the feedback activity. Allow users to provide feedback without
	 * prior call to {@link #begin(Context, String)}. All feedback will appear in your
	 * build report page, and in the "Feedbacks" tab. Given screenshot will be attached
	 * to the feedback.
	 *
	 * This method is different from {@link #showFeedbackForm()} by that it does not
	 * require a call to begin().
	 *
	 * @param context
	 * @param appToken
	 * @param screenshot
	 */
	public static void showFeedbackForm(Context context, String appToken, Bitmap screenshot) {
		//stub
	}

	/**
	 * Sends all remaining feedbacks saved to disk due to lost internet connection
	 * or any kind of failure mode. This is also done automatically if {@link #begin(Context, String)}
	 * or {@link #showFeedbackForm()} is called.
	 *
	 * @param context
	 * @param appToken
	 */
	public static void sendPendingFeedbacks(Context context, String appToken) {
		//stub
	}

	/**
	 * Installs shake gesture recognizer for sending feedbacks.
	 *
	 * This is also done automatically if {@link #begin(Context, String)} is called.
	 * @param context
	 * @param appToken
	 */
	public static void installFeedbackHandler(Context context, String appToken) {
		//stub
	}

	/**
	 * Uninstalls shake gesture recognizer for sending feedbacks.
	 */
	public static void uninstallFeedbackHandler() {
		//stub
	}

	/**
	 * Attempts to take a screenshot for the current moment in session.
	 */
	public static void takeScreenshot() {
		//stub
	}

	/**
	 * Attempts to take a screenshot and calls the listener with Bitmap if it is successful.
	 *
	 * @param context App context
	 * @param listener Callback for receiving Bitmap of the taken screenshot
	 */
	public void takeScreenshot(Context context, TakeScreenshotListener listener) {
		//stub
	}

	/**
	 * Adds a screenshot to the current moment in session.
	 * @param screenshot Screenshot to add
	 */
	public static void addScreenshot(Bitmap screenshot) {
		//stub
	}

	/**
	 * Stops the current session recording. Unlike 'pause', when
	 * calling 'resume', a new session will be created and will be
	 * linked to the previous recording. Useful if you want short
	 * session recordings of specific use-cases of the app. Hidden
	 * views and user identity will be applied to the new session
	 * as well, if started.
	 */
	public static void stop() {
		//stub
	}

	/**
	 * Resumes the recording of the current session. This method resumes a session after it was paused. Has no effect
	 * is already resumed.
	 */
	public static void resume() {
		//stub
	}

	/**
	 * Pauses the current session. This method stops recoding of the current session until resume has been called. Has
	 * no effect if already paused.
	 */
	public static void pause() {
		//stub
	}

	/**
	 * Send a VERBOSE log message and log the exception to TestFairy. This is an alternative to
	 * android.util.Log, as logs are sent without being available in logcat.
	 *
	 * @param tag Used to identify the source of a log message. It usually identifies the class or activity where the log call occurs.
	 * @param msg The message you would like logged.
	 */
	public static void log(String tag, String msg) {
		//stub
	}

	/**
	 * Send a throwable to TestFairy.
	 * Note, this function is limited to 5 throwable.
	 * @param throwable Throwable
	 */
	public static void logThrowable(Throwable throwable) {
		//stub
	}

	/**
	 * Send a stacktrace to TestFairy.
	 * @param stacktrace String
	 */
	public static void logThrowable(String stacktrace) {
		//stub
	}

	/**
	 * Attach a file to the session. A maximum of 5 files may be attached. Each file cannot be more
	 * than 15 mb in size. In order to see if the file successfully uploads or fails, please view
	 * the logs.
	 *
	 * @param file file to upload
	 */
	public static void attachFile(File file) {
		//stub
	}

	/**
	 * Accept a log event entry. By returning true, TestFairy will send this log to server.
	 * Otherwise, log event will be discarded.
	 */
	public interface LogEventFilter extends com.testfairy.LogEventFilter {}

	/**
	 * Set a custom log event filter, get a callback whenever a new log has been read from device and accept
	 * each one by implementing a LogEventFilter.
	 *
	 * @param filter LogEventFilter
	 */
	public static void setLogEventFilter(LogEventFilter filter) {
		//stub
	}

	/**
	 * Set a custom name for the current screen. Useful for applications that don't use more than one
	 * Activity. This name is displayed for a given screenshot, and will override the name of the current
	 * Activity.
	 *
	 * @param name String
	 */
	public static void setScreenName(String name) {
		//stub
	}

	public static void addSessionStateListener(SessionStateListener listener)
	{
		//stub
	}

	/**
	 * You can customize the feedback form by creating FeedbackOptions,
	 * See {@link com.testfairy.FeedbackOptions.Builder FeedbackOptions.Builder }
	 *
	 * @param options FeedbackOptions
	 */
	public static void setFeedbackOptions(FeedbackOptions options) {
		//stub
	}

	/**
	 * Provide a custom verification class for feedbacks. This allows you
	 * to control the checks that are done against the feedback's content
	 * and email address. If not provided, TestFairy will check for valid
	 * email (if mandatory) and feedback text. By providing your own class,
	 * you can, for example, add checks for email addresses ending with
	 * your own company domain.
	 *
	 * @param verifier Custom {@link FeedbackVerifier} implementation
	 */
	public static void setFeedbackVerifier(FeedbackVerifier verifier) {
		//stub
	}

	/**
	 * Call this function to log your network events.
	 *
	 * @param uri {@link URI}
	 * @param method {@link String}
	 * @param code int
	 * @param startTimeMillis long
	 * @param endTimeMillis long
	 * @param requestSize long
	 * @param responseSize long
	 * @param errorMessage {@link String}
	 */
	public static void addNetworkEvent(URI uri, String method, int code, long startTimeMillis, long endTimeMillis, long requestSize, long responseSize, String errorMessage) {
		//stub
	}

	/**
	 * Call this function to log your network events.
	 *
	 * @param uri {@link URI}
	 * @param method {@link String}
	 * @param code int
	 * @param startTimeMillis long
	 * @param endTimeMillis long
	 * @param requestSize long
	 * @param responseSize long
	 * @param errorMessage {@link String}
	 * @param requestHeaders String Include these request headers in network event
	 * @param requestBody byte[] Include this request payload in network event (limited to 100KB)
	 * @param responseHeaders String Include these response headers in network event
	 * @param responseBody byte[] Include this response body in network event (limited to 100KB)
	 */
	public static void addNetworkEvent(URI uri, String method, int code, long startTimeInMillis, long endTimeInMillis, long requestSize, long responseSize, String errorMessage, String requestHeaders, byte[] requestBody, String responseHeaders, byte[] responseBody) {
		//stub
	}

	/**
	 * Indicate in runtime whether your last session was crashed.
	 *
	 * The crashless Sauce Mobile Beta artifact always returns false.
	 * Use Backtrace for crash history.
	 *
	 * @param context Context
	 * @return true will be returned if the last session was crashed, otherwise false will be returned
	 */
	public static boolean didLastSessionCrash(Context context) {
		//stub
	}

	/**
	 * Enables the ability to capture crashes. TestFairy
	 * crash handler is installed by default. Once installed
	 * it cannot be uninstalled. Must be called before begin.
	 * This method is unavailable in the crashless Sauce Mobile Beta artifact.
	 */
	public static void enableCrashHandler() {
		//stub
	}

	/**
	 * Disables the ability to capture crashes. TestFairy
	 * crash handler is installed by default. Once installed
	 * it cannot be uninstalled. Must be called before begin.
	 * Crash handling is already unavailable in the Sauce Mobile Beta artifact.
	 */
	public static void disableCrashHandler() {
		//stub
	}

	/**
	 * Installs the crash reporter without requiring a session. Call this instead of
	 * TestFairy.begin() if you don't need to have recorded sessions.
	 * This method returns without initialization in the crashless Sauce Mobile
	 * Beta artifact. Use Backtrace for crash reporting.
	 *
	 * @param context
	 * @param appToken
	 */
	public static void installCrashHandler(Context context, String appToken) {
		//stub
	}

	/**
	 * Enables recording of a metric regardless of build settings.
	 * Valid values include "cpu", "memory", "logcat", "battery", "network-requests"
	 * A metric cannot be enabled and disabled at the same time, therefore
	 * if a metric is also disabled, the last call to enable to disable wins.
	 * Must be called before begin.
	 *
	 * @param metric
	 */
	public static void enableMetric(String metric) {
		//stub
	}

	/**
	 * Disables recording of a metric regardless of build settings.
	 * Valid values include "cpu", "memory", "logcat", "battery", "network-requests"
	 * A metric cannot be enabled and disabled at the same time, therefore
	 * if a metric is also disabled, the last call to enable to disable wins.
	 * Must be called before begin.
	 */
	public static void disableMetric(String metric) {
		//stub
	}

		/**
	 * Enables capture of logs in a session. Must be called begin.
	 */
	public static void enableLogs() {
		//stub
	}

	/**
	 * Disables capture of logs in a session. Must be called begin.
	 */
	public static void disableLogs() {
		//stub
	}

	/**
	 * Enables the ability to capture video recording regardless of build settings.
	 * Valid values for policy include "always", "wifi" and "none"
	 *
	 * @param policy
	 */
	@Deprecated
	public static void enableVideo(String policy) {
		//stub
	}

	/**
	 * Enables the ability to capture video recording regardless of build settings.
	 * Valid values for policy include "always", "wifi" and "none"
	 * Valid values for quality include "high", "low", "medium"
	 * Values for fps must be between 0.1 and 2.0. Value will be rounded to
	 * the nearest frame.
	 *
	 * @param policy
	 * @param quality
	 * @param fps
	 */
	@Deprecated
	public static void enableVideo(String policy, String quality, float fps) {
	    //stub
	}

	/**
	 * Disables the ability to capture video recording. Must be
	 * called before begin.
	 */
	public static void disableVideo() {
		//stub
	}

	/**
	 * Enables the ability to present the feedback form
	 * based on the method given. Valid values only include
	 * "shake". If an unrecognized method is passed,
	 * the value defined in the build settings will be
	 * used. Must be called before begin.
	 *
	 * @param method
	 */
	public static void enableFeedbackForm(String method) {
		//stub
	}

	/**
	 * Disables the ability to present users with feedback when
	 * devices is shaken, or if a screenshot is taken. Must be called
	 * before begin.
	 */
	public static void disableFeedbackForm() {
		//stub
	}

	/**
	 * Disables auto update prompts for this session. Must be called
	 * before begin.
	 */
	public static void disableAutoUpdate() {
		//stub
	}

	/**
	 * Sets the maximum recording time. Minimum value is 60 seconds,
	 * else the value defined in the build settings will be used. The
	 * maximum value is the lowest value between this value and the
	 * value defined in the build settings.
	 *
	 * Time is rounded to the nearest minute.
	 *
	 * Must be called before begin.
	 *
	 * @param seconds Maximum session length in seconds
	 */
	public static void setMaxSessionLength(float seconds) {
		//stub
	}

	/**
	 * Query about the distribution status of this build. Distribution is not required
	 * for working with the TestFairy SDK, meaning, you can use the SDK with Google Play.
	 *
	 * The distribution status can be either Enabled or Disabled, and optionally, can have
	 * an auto-update. This method is useful if you're using TestFairy in your development
	 * stage and want to know if you expired the distribution of this version in your dashboard.
	 *
	 * @param context Context
	 * @param appToken App token as used with begin()
	 * @param listener Listener to receive asynchronous response
	 */
	public static void getDistributionStatus(Context context, String appToken, DistributionStatusListener listener) {
		//stub
	}

	/**
	 * Enable end-to-end encryption for this session. Screenshots and logs will be encrypted using
	 * this RSA key. Please refer to the documentation to learn more about the subject and how
	 * to create public/private key pair.
	 *
	 * @param publicKey64 RSA Public Key converted to DER format and encoded in base64
	 */
	public static void setPublicKey(String publicKey64) {
		//stub
	}

	/**
	 * Override default encryption policy for encrypted sessions. If not called, both logs and
	 * video will always be encrypted. Must be called after `TestFairy.setPublicKey()`.
	 *
	 * Warning: Calling this method will relax the existing security measures. Proceed with caution!
	 *
	 * @param encryptLogs Whether logs should be encrypted (true) or sent in plain text (false). Default is true.
	 * @param encryptVideo Whether video and screenshots should be encrypted (true) or not (false). Default is true.
	 */
	public static void setEncryptionPolicy(boolean encryptLogs, boolean encryptVideo) {
		//stub
	}

	/**
	 * Kind of user interactions to add to the session timeline.
	 */
	public enum UserInteractionKind {
		/**
		 * A single tap event, also known as click
		 */
		USER_INTERACTION_BUTTON_PRESSED(1),

		/**
		 * A single long tap event
		 */
		USER_INTERACTION_BUTTON_LONG_PRESSED(8),

		/**
		 * A quick double tap event, also known as double click
		 */
		USER_INTERACTION_BUTTON_DOUBLE_PRESSED(9);

		private final int kind;

		UserInteractionKind(int kind) {
			this.kind = kind;
		}
	}

	/**
	 * Adds a new user interaction to the timeline. Can be used by non-native UI frameworks to report
	 * user interactions such as clicks, long-clicks and double clicks.
	 *
	 * @param kind Kind of interaction to add
	 * @param label Text content of the clicked view
	 @param info (Optional) Extra meta data, accepted keys are "accessibilityLabel", "accessibilityIdentifier", "accessibilityHint", "scrollableParentAccessibilityIdentifier", "textInScrollableParent and "className"
	 */
	public static void addUserInteraction(UserInteractionKind kind, String label, Map<String, String> info) {
		//stub
	}
}
