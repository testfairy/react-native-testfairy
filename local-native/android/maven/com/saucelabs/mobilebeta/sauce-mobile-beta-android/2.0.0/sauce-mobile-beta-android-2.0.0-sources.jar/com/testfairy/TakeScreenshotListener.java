package com.testfairy;

import android.graphics.Bitmap;

/**
 * Callback for receiving Bitmap objects when a screenshot is taken
 */
public interface TakeScreenshotListener {
	/**
	 * Attempts to take a screenshot and calls the listener with Bitmap if it is successful.
	 *
	 * @param context App context
	 * @param appToken App token
	 * @param listener Callback for receiving Bitmap of the taken screenshot
	 */
	void takeScreenshot(Context context, String appToken, TakeScreenshotListener listener);
}
