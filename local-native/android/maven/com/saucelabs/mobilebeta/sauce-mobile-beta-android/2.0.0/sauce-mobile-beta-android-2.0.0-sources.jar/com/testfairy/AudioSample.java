package com.testfairy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AudioSample {

	// Header template to copy into each Wave file, will be edited after copy.
	static private final byte[] header = {
			'R', 'I', 'F', 'F',
			'0', '0', '0', '0',     // chunk size
			'W', 'A', 'V', 'E',
			'f', 'm', 't', ' ',
			0x10, 0x00, 0x00, 0x00, // subchunk size (16 bytes)
			0x01, 0x00,             // audio format pcm
			0x01, 0x00,             // total channels
			0x00, 0x00, 0x00, 0x00, // sample rate
			0x00, 0x00, 0x00, 0x00, // byte rate
			0x04, 0x00,             // block align
			0x10, 0x00,             // bits per sample
			'd', 'a', 't', 'a',
			0x00, 0x00, 0x00, 0x00, // total sample data size
	};

	private int sampleRate;
	private int bitsPerSample;
	private int channels;
	private int source;
	private float timestamp;
	private byte[] audioData;
	private byte[] wavFile;

	/**
	 * Constructs an audio sample
	 *
	 * @param sampleRate
	 * @param bitsPerSample
	 * @param channels
	 * @param source
	 * @param timestamp
	 * @param audioData
	 */
	public AudioSample(int sampleRate, int bitsPerSample, int channels, int source, float timestamp, byte[] audioData) {
		this.sampleRate = sampleRate;
		this.bitsPerSample = bitsPerSample;
		this.channels = channels;
		this.source = source;
		this.timestamp = timestamp;
		this.audioData = audioData;
	}

	/**
	 * Returns audio sample rate.
	 *
	 * @return int
	 */
	public int getSampleRate() {
		return sampleRate;
	}

	/**
	 * Returns number of bits per sample.
	 *
	 * @return int
	 */
	public int getBitsPerSample() {
		return bitsPerSample;
	}

	/**
	 * Returns number of channels.
	 *
	 * @return int
	 */
	public int getChannels() {
		return channels;
	}

	/**
	 * Returns source meta data.
	 *
	 * @return int
	 */
	public int getSource() {
		return source;
	}

	/**
	 * Returns number of seconds passed since session start.
	 *
	 * @return float
	 */
	public float getTimestamp() { return timestamp; }

	/**
	 * Returns sample duration in milliseconds.
	 *
	 * @return int
	 */
	public int getDurationInMilliseconds() {
		int samples = audioData.length;
		if (getChannels() == 2) {
			samples >>= 1;
		}

		if (getBitsPerSample() == 16) {
			samples >>= 1;
		}

		float duration = (samples/sampleRate);

		return (int) (duration * 1000);
	}

	public void destroy() {
		this.audioData = null;
		this.wavFile = null;
	}

	/**
	 * Joins all audio chunks into one playable RIFF wave file.
	 *
	 * @return byte[]
	 * @throws IOException
	 */
	public byte[] toWavFile() throws IOException {
		ByteArrayOutputStream baos = null;
		try {
			if (wavFile != null) return wavFile;
			if (audioData == null) throw new NullPointerException("Non empty audio data must be provided. Have you destroyed the sample by accident?");

			baos = new ByteArrayOutputStream();

			baos.write(header);
			baos.write(audioData, 0, audioData.length);

			byte[] out = baos.toByteArray();

			int byteRate = (sampleRate * bitsPerSample * channels) / 8;
			int fileSize = out.length + header.length - 4;

			out[0x04] = (byte) (fileSize & 0xff);
			out[0x05] = (byte) ((fileSize >> 8) & 0xff);
			out[0x06] = (byte) ((fileSize >> 16) & 0xff);
			out[0x07] = (byte) ((fileSize >> 24) & 0xff);

			out[0x16] = (byte) (channels & 0xff);

			out[0x18] = (byte) (sampleRate & 0xff);
			out[0x19] = (byte) ((sampleRate >> 8) & 0xff);
			out[0x1a] = (byte) ((sampleRate >> 16) & 0xff);
			out[0x1b] = (byte) ((sampleRate >> 24) & 0xff);

			out[0x1c] = (byte) (byteRate & 0xff);
			out[0x1d] = (byte) ((byteRate >> 8) & 0xff);
			out[0x1e] = (byte) ((byteRate >> 16) & 0xff);
			out[0x1f] = (byte) ((byteRate >> 24) & 0xff);

			out[0x22] = (byte) (bitsPerSample & 0xff);
			out[0x23] = (byte) ((bitsPerSample >> 8) & 0xff);

			out[0x28] = (byte) (out.length & 0xff);
			out[0x29] = (byte) ((out.length >> 8) & 0xff);
			out[0x2a] = (byte) ((out.length >> 16) & 0xff);
			out[0x2b] = (byte) ((out.length >> 24) & 0xff);

			wavFile = out;
			audioData = null;

			baos.close();
			baos = null;

			return wavFile;
		} finally {
			if (baos != null) {
				baos.close();
			}
		}
	}
}