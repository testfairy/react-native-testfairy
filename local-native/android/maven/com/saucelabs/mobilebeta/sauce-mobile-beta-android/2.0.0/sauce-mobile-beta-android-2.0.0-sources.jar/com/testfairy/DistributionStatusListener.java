package com.testfairy;

import com.testfairy.DistributionStatus;

public interface DistributionStatusListener {

	/**
	 * Called upon a response for getDistributionStatus().
	 *
	 * @param status
	 */
	void onResponse(DistributionStatus status);
}
