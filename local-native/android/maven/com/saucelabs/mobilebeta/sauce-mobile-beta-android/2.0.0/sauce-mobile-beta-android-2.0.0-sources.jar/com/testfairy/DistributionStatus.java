package com.testfairy;

public interface DistributionStatus {

	/**
	 * Is distribution enabled for this specific build? That is, an APK was uploaded
	 * to TestFairy with the same package name, version name and version code as the
	 * app we're running right now.
	 *
	 * @return boolean
	 */
	boolean isEnabled();

	/**
	 * Is auto-update available for this build? Meaning, there is a newer version
	 * uploaded to TestFairy, with the same package name, but uploaded later and is
	 * marked as "auto-update".
	 *
	 * @return boolean
	 */
	boolean isAutoUpdateAvailable();

	/**
	 * If isAutoUpdateAvailable() returned true, then getAutoUpdateDownloadUrl() will also
	 * return the URL of the newer version's APK file. This url is signed with a timestamp,
	 * and will expire automatically.
	 *
	 * @return URL address
	 */
	String getAutoUpdateDownloadUrl();
}
