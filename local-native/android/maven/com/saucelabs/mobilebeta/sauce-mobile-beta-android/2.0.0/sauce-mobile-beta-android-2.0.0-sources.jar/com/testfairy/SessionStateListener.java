package com.testfairy;

public class SessionStateListener {

	/**
	 * Callback when a session has successfully started on TestFairy.
	 * The sessionUrl parameter points to the web page where you can see the
	 * video recording and other metrics.
	 *
	 * @param sessionUrl
	 */
	public void onSessionStarted(String sessionUrl) {
	}

	/**
	 * Callback when a session failed to started. Could be because the recording
	 * is set to off, session limit has reached, request rejected or other reasons.
	 *
	 */
	public void onSessionFailed() {
	}

	/**
	 * Callback when session length has reached. For example, if your session
	 * is set to maximum of 10 minutes, you will get a callback if such a limit
	 * was reached. You can start a new session if you wish to do so.
	 *
	 * @param secondsFromStartSession
	 */
	public void onSessionLengthReached(float secondsFromStartSession) {
	}

	/**
	 * Callback when session recording stopped. Could be because session length
	 * reached the limit, stop() was called, app moved to background for too long,
	 * or similar reason.
	 *
	 */
	public void onSessionStopped() {
	}

	/**
	 * Callback when there is an update available. Either this method is called,
	 * or onNoAutoUpdateAvailable() is called.
	 *
	 * @param url
	 */
	public void onAutoUpdateAvailable(String url) {
	}

	/**
	 * Callback when a user was presented for a request of an auto-update, and
	 * then clicked "Yes".
	 */
	public void onAutoUpdateDownloadStarted() {
	}

	/**
	 * Callback when a user was displayed with a dialog asking if they would like to upgrade,
	 * and they clicked "No".
	 *
	 */
	public void onAutoUpdateDismissed() {
	}

	/**
	 * Callback when the download of an auto-update completes successfully.
	 *
	 */
	public void onAutoUpdateDownloadCompleted() {
	}

	/**
	 * Callback when a download of an auto-update fails and stops.
	 *
	 */
	public void onAutoUpdateDownloadFailed() {
	}

	/**
	 * Callback when session start was requested and there was no auto update
	 * available. In this case, the user will not be displayed with a dialog box. Note
	 * that onSessionFailed() could still be called.
	 */
	public void onNoAutoUpdateAvailable() {
	}
}
