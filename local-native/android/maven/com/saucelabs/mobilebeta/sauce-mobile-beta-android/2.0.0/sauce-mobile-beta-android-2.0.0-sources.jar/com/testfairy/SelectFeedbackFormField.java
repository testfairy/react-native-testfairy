package com.testfairy;

import android.content.Context;
import android.content.res.Resources;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;

/**
 * A dropdown element to represent single choice options, like an HTML select node.
 */
public class SelectFeedbackFormField implements FeedbackFormField, AdapterView.OnItemSelectedListener {

	private interface SetFieldValue<T> {
		void selectKey(T value);
	}

	private static final int MARGIN = 25;

	private final String attribute;
	private final String label;
	private final String defaultValue;
	private final List<String> keys = new ArrayList<>(); // Human readable items in the spinner, will be filled during populating the spinner
	private final Map<String, String> values; // Machine friendly values of the items in the spinner. Contains all keys in the list above.

	private SetFieldValue<String> setFieldValue = null;
	private String fieldValue;

	public SelectFeedbackFormField(String attribute, String label, Map<String, String> values, String defaultValue) {
		this.attribute = attribute != null ? attribute : "";
		this.label = label != null ? label : "";
		this.values = values != null ? values : new HashMap<String, String>();
		this.defaultValue = defaultValue != null ? defaultValue : "";
		this.fieldValue = defaultValue;
	}

	@Override
	public View onCreateView(Context context, View parent) {
		this.fieldValue = defaultValue;

		// Configure views
		final LinearLayout container = new LinearLayout(context);
		container.setOrientation(LinearLayout.HORIZONTAL);
		container.setWeightSum(1f);

		final Button selectLabel = new Button(context);
		final SelectionSpinner selectView = new SelectionSpinner(context, Spinner.MODE_DIALOG);

		selectLabel.setText(label);
		selectLabel.setContentDescription(label);
		selectLabel.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
		selectLabel.setCompoundDrawablePadding((int) dpToPx(context, 20));
		selectLabel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				selectView.performClick();
			}
		});
		selectLabel.setClickable(true);

		// Prepare list and default value
		keys.clear();
		keys.addAll(values.keySet());
		int defaultIndex = keys.indexOf(defaultValue);
		if (defaultIndex == -1) {
			keys.add(0, defaultValue);
		}

		// Setup adapter
		final ArrayAdapter<String> spinnerArrayAdapter = new SelectionAdapter<>(context, android.R.layout.simple_spinner_item, new ArrayList<>(keys));

		// Setup field updater
		setFieldValue = new SetFieldValue<String>() {
			@Override
			public void selectKey(String value) {
				int index = keys.indexOf(value);
				if (index != -1) {
					final int finalIndex = index;
					container.post(new Runnable() {
						@Override
						public void run() {
							selectView.setAdapter(spinnerArrayAdapter);
							selectView.setOnItemSelectedListener(SelectFeedbackFormField.this);
							selectView.setSelectionManually(finalIndex);
						}
					});
				}
			}
		};

		// Setup container layout params
		if (parent instanceof LinearLayout) {
			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			layoutParams.setMargins(MARGIN, 0, MARGIN, MARGIN);
			container.setLayoutParams(layoutParams);
		}

		// This is needed to make the SelectionSpinner work even when selections are made during initial
		setFieldValue.selectKey(defaultValue);

		// Prepare layout params for label on the left, put into container
		{
			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			layoutParams.setMargins(0, 0, 0, 0);
			layoutParams.weight = 0.4f;
			selectLabel.setLayoutParams(layoutParams);
			container.addView(selectLabel, layoutParams);
		}

		// Prepare layout params for spinner on the right, put into container
		{
			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			layoutParams.setMargins(0, 0, 0, 0);
			layoutParams.weight = 0.6f;
			selectView.setLayoutParams(layoutParams);
			container.addView(selectView, layoutParams);
		}

		return container;
	}

	@Override
	public String getAttribute() {
		return attribute;
	}

	@Override
	public String getValue() {
		return fieldValue;
	}

	@Override
	public synchronized void onItemSelected(final AdapterView<?> parent, View view, int position, long id) {
		// For SelectionSpinner to fix the "desynchronized selections" bug on Samsung devices,
		// listeners are set up in a way to call this method 2 times instead of 1. Both calls will have the same arguments,
		// so we can test whether it is the first or second call by comparing previous field value with currently given one.
		//
		// First call is used to immediately update our inner field data and spinner with the new value.
		//
		// Second call is used to force layout right before dialog closes. If we are too late, UI will desynchronize (the bug on Samsung devices) with the state.
		//
		// These calls will be made in consecutive ticks and the correct order to avoid the race condition is always guaranteed.

		String key = keys.get(position);
		String newValue = values.containsKey(key) ? values.get(key) : defaultValue;

		if (!fieldValue.equals(newValue)) { // true for the first call
			fieldValue = newValue;

			((SelectionSpinner) parent).setSelectionManually(position);
		}

		// This is needed to make the SelectionSpinner work even when selections are made during initial layout. Will happen for both calls.
		parent.post(new Runnable() {
			@Override
			public void run() {
				parent.invalidate();
				parent.forceLayout();

				SelectionAdapter<String> adapter = (SelectionAdapter<String>) parent.getAdapter();
				adapter.notifyDataSetChanged();
			}
		});
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		fieldValue = defaultValue;
	}

	/**
	 * Set current selection to given value
	 *
	 * @param value
	 */
	public void setSelection(String value) {
		if (setFieldValue != null && value != null) {
			for (Map.Entry<String, String> e: values.entrySet()){
				if (value.equals(e.getValue())) {
					setFieldValue.selectKey(e.getKey());
					return;
				}
			}
		}
	}

	private static float dpToPx(Context context, float dp) {
		Resources r = context.getResources();
		return TypedValue.applyDimension(
			TypedValue.COMPLEX_UNIT_DIP,
			dp,
			r.getDisplayMetrics()
		);
	}

	/**
	 * Spinner extension that calls onItemSelected even when the selection is the same as its previous value.
	 *
	 * Supports manual override of the currently set value even when it is set during layout.
	 *
	 * <p>
	 * Fixes an unwanted view interaction freeze on Samsung devices.
	 */
	private static class SelectionAdapter<T> extends ArrayAdapter<T> {

		public SelectionAdapter(Context context, int resource, List<T> objects) {
			super(context, resource, objects);
		}

		@Override
		// Anyone of these can be preferred by the system if OS ignores our Spinner mode (dialog vs dropdown)
		public View getView(int position, View convertView, final ViewGroup parent) {
			final View view = super.getView(position, convertView, parent);
			fixItemState(view, parent);

			return view;
		}

		@Override
		// Anyone of these can be preferred by the system if OS ignores our Spinner mode (dialog vs dropdown)
		public View getDropDownView(int position, View convertView, final ViewGroup parent) {
			final View view = super.getDropDownView(position, convertView, parent);
			fixItemState(view, parent);

			return view;
		}

		// This is needed to make the SelectionSpinner work even when selections are made during initial layout
		private void fixItemState(View view, final ViewGroup parent) {
			// We don't know what kind of theme the OS will use for the dialog.
			// Adding some margin is always safer than obeying OS defaults.
			//
			// i.e Huawei's default is 0 which looks terrible.
			view.setPadding(MARGIN, MARGIN, MARGIN, MARGIN);

			// Fix selection states if view is reused (Spinner is a ListView behind the scenes)
			view.setSelected(false);
			view.setActivated(false);

			// Force layout on next tick to reflect the changes even when the spinner is closed.
			parent.post(new Runnable() {
				@Override
				public void run() {
					parent.invalidate();
					parent.forceLayout();
				}
			});
		}
	}

	/**
	 * Spinner extension that calls listener.onItemSelected() even when the selection is the same as its previous value.
	 *
	 * Supports manual override of the currently set value even when it is set during layout.
	 *
	 * <p>
	 * Fixes an unwanted view interaction freeze on Samsung devices.
	 */
	private static class SelectionSpinner extends Spinner {

		public SelectionSpinner(Context context, int mode) {
			super(context, mode);
		}

		@Override
		public void
		setSelection(int position, boolean animate) {
			// Call listeners no matter what
			if (getOnItemSelectedListener() != null) {
				// Spinner does not call the OnItemSelectedListener if the same item is selected, so do it manually now
				getOnItemSelectedListener().onItemSelected(this, getSelectedView(), position, getSelectedItemId());
			}

			super.setSelection(position);
		}

		@Override
		public void
		setSelection(int position) {
			// Call listeners no matter what
			if (getOnItemSelectedListener() != null) {
				// Spinner does not call the OnItemSelectedListener if the same item is selected, so do it manually now
				getOnItemSelectedListener().onItemSelected(this, getSelectedView(), position, getSelectedItemId());
			}
		}

		// Call this to make sure UI really changes no matter what, see SelectionAdapter.onItemSelected()
		public void setSelectionManually(int position) {
			// We are enforcing a reselection by making sure previously selected value is different
			if (position != 0) {
				super.setSelection(0, false);
			} else {
				int count = getAdapter().getCount();

				if (count > 1) {
					super.setSelection(1, false);
				}
			}

			super.setSelection(position, false);
		}

		@Override
		public void setOnItemSelectedListener(OnItemSelectedListener listener) {
			// When immediately after initialization, listeners are called with zero state.
			//
			// First add data, only then set listener.
			//
			// Having done this, you may refresh adapter data as many times as you want
			setSelection(0, false);
			super.setOnItemSelectedListener(listener);
		}
	}
}