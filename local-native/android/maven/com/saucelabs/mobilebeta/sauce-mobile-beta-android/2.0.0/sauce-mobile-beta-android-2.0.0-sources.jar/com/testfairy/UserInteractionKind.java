package com.testfairy;

/**
 * Kind of user interactions to add to the session timeline.
 */
public enum UserInteractionKind {
	/**
	 * A single tap event, also known as click
	 */
	USER_INTERACTION_BUTTON_PRESSED(1),

	/**
	 * A single long tap event
	 */
	USER_INTERACTION_BUTTON_LONG_PRESSED(8),

	/**
	 * A quick double tap event, also known as double click
	 */
	USER_INTERACTION_BUTTON_DOUBLE_PRESSED(9);

	public final int kind;

	UserInteractionKind(int kind) {
		this.kind = kind;
	}
}