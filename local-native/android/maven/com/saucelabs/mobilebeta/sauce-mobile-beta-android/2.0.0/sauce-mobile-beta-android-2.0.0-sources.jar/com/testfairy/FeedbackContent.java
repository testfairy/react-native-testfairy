package com.testfairy;

import android.graphics.Bitmap;

public class FeedbackContent {
	private String email;
	private String text;
	private float timestamp;
	private Bitmap bitmap;

	/**
	 * Constructs a new feedback content object
	 *
	 * @param text User feedback message
	 * @param email User email
	 * @param timestamp Time in seconds since the beginning of app launch or last call to TestFairy.begin()
	 */
	public FeedbackContent(String text, String email, float timestamp) {
		// stub
	}

	/**
	 * Constructs a new feedback content object
	 *
	 * @param text User feedback message
	 * @param email User email
	 * @param timestamp Time in seconds since the beginning of app launch or last call to TestFairy.begin()
	 * @param bitmap Attached screenshot
	 */
	public FeedbackContent(String text, String email, float timestamp, final Bitmap bitmap) {
		// stub
	}

	/**
	 * Feedback text
	 *
	 * @return String
	 */
	public String getText() {
		// stub
	}

	/**
	 * User email
	 *
	 * @return String
	 */
	public String getEmail() {
		// stub
	}

	/**
	 * Feedback time in seconds since the beginning of app launch or last call to TestFairy.begin()
	 *
	 * @return float
	 */
	public float getTimestamp() {
		// stub
	}

	/**
	 * Attached screenshot or null if there is none
	 *
	 * @return Bitmap
	 */
	public Bitmap getBitmap() {
		// stub
	}
}
